/**
 * Create an appropriate GDAL path to an S3 object
 *
function buildDestinationVSIS3Path(_options, name) {
    return `/vsis3/${bucket}/${key}`;
}
*/

module.exports = {
//    buildDestinationVSIS3Path
}